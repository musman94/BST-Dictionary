//
//  Dictionary23Tree.cpp
//  HW4
//
//  Created by Muhammad Usman on 4/19/16.
//  Copyright © 2016 Muhammad Usman. All rights reserved.
//

#include <fstream>
#include <iostream>
#include <string>
#include <stdio.h>
#include "Dictionary23Tree.h"
using namespace std;

Dictionary23Tree::Dictionary23Tree(string dictionaryFile)
{
    
    treeHeight = 0;
    counter = 0;
    rootptr = NULL;
    string word;
    ifstream file(dictionaryFile, ios::in);
    if(!file)
        exit(EXIT_FAILURE);
    while(file >> word)
        insert(word);


}

void Dictionary23Tree::insert( string word )
{
    char temp = word[0];
    int position = temp;
    btreeNode *item = nodeMaker(position,word,NULL,NULL,NULL);
    add(rootptr,parent,item);
    
    
}


void Dictionary23Tree::search( string word, int& numComparisons, bool& found )
{

    char temp = word[0];
    int key = temp;
    check = 0;
    find(rootptr,word,key ,numcomparisions,check);
    if(max_comp < numcomparisions)
        max_comp = numcomparisions;
    total_comp = total_comp + numcomparisions;
    ofstream output;
    output.open(outfile,ios::app);
    output << word << " " << check << " " << numcomparisions << endl;
    numcomparisions = 0;
    check = 0;
    output.close();
}


void Dictionary23Tree::search( string queryFile, string outputFile )
{

    outfile = outputFile;
    query_size = 0;
    numcomparisions = 0;
    found = 0;
    max_comp = 0;
    total_comp = 0;
    avg_comp = 0;
    string query_word;
    ifstream query(queryFile,ios::in);
    if(!query)
        exit(EXIT_FAILURE);
    while(query >> query_word)
    {
        query_size++;
        search(query_word,numcomparisions,found);
    }
    
    avg_comp = (double)total_comp/(double)query_size;
    ofstream output2;
    output2.open(outfile,ios::app);
    output2 << "# of queries: " << query_size << endl;
    output2 << "Maximum # of comparisons: " << max_comp << endl;
    output2 << "Average # of comparisons: " << avg_comp << endl;
    output2.close();


}



void Dictionary23Tree::find(btreeNode* rootptr, string query_word, int key, int &numComaprisions, int &check)
{
    if(rootptr != NULL)
    {
        numcomparisions++;
        if(rootptr != NULL)
        {
            
            if((rootptr -> full == true) && (child(rootptr) == false))
            {
                if((key == rootptr -> key1) && (query_word == rootptr -> smallitem))
                    check = 1;
                else if((key == rootptr -> key2) && (query_word == rootptr -> largeitem))
                    check = 1;
                else
                    check = 0;
            
            }
            
            if((rootptr -> full == false) && (child(rootptr) == false))
            {
                if((key == rootptr -> key1) && (query_word == rootptr -> smallitem))
                    check = 1;
                else
                    check = 0;
            
            }
            
            else if((rootptr -> full == true) && (child(rootptr) == true))
            {
                if((key == rootptr -> key1) && (query_word == rootptr -> smallitem))
                    check = 1;
                else if((key == rootptr -> key2) && (query_word == rootptr -> largeitem))
                    check = 1;
                else if(key < rootptr -> key1)
                    find(rootptr -> left, query_word, key, numComaprisions, check);
                else if(key < rootptr -> key2)
                    find(rootptr -> middle, query_word, key, numComaprisions, check);
                else
                    find(rootptr -> right, query_word, key, numComaprisions, check);
            
            }
            
            else if((rootptr -> full == false) && (child(rootptr) == true))
            {
                if(key == rootptr -> key1)
                    check = 1;
                else if(key < rootptr -> key1)
                    find(rootptr -> left,query_word,key,numComaprisions,check);
                else
                    find(rootptr -> middle, query_word, key, numComaprisions, check);
            
            
            }
            
        }
    }
}



// Adds a new node to the tree
void Dictionary23Tree::add(btreeNode *&rootptr, btreeNode *&parent,btreeNode *item)
{
    if(rootptr == NULL)
    {
        rootptr = item;
        parent = rootptr;
        orgRoot = parent;
        //treeHeight++;
    }
    else if((rootptr -> full == false) && (child(rootptr) == false))
        nodeEdit(rootptr, item -> key1, item -> smallitem);
    else if((rootptr -> full == true) && (child(rootptr) == false))
    {
        //treeHeight++;
        split(rootptr, parent, orgRoot ,item);
        counter = 0;
    }
 
    else if(rootptr -> full == true)
    {
        if(item -> key1 < rootptr -> key1)
            add(rootptr -> left,rootptr, item);
        else if(item -> key1 < rootptr -> key2)
            add(rootptr -> middle, rootptr, item);
        else
            add(rootptr -> right, rootptr, item);
    }
    
    else
    {
        if(item -> key1 < rootptr -> key1)
            add(rootptr -> left,rootptr, item);
        else if(item -> key1 > rootptr -> key1)
            add(rootptr -> middle, rootptr, item);
    
    }
    
}


// Makes a node with 2 children
btreeNode* Dictionary23Tree::nodeMaker(int key, string word, btreeNode *left, btreeNode *middle, btreeNode *right)
{
    btreeNode *node = new btreeNode();
    node -> key1 = key;
    node -> smallitem = word;
    node -> largeitem = " ";
    node -> left = left;
    node -> middle = middle;
    node -> right = right;
    return node;
}

// Makes a node with 3 children
btreeNode* Dictionary23Tree::twonodeMaker(int key1, int key2, string small, string large, btreeNode* left, btreeNode *middle, btreeNode *right)
{
    btreeNode *node = new btreeNode();
    node -> key1 = key1;
    node -> key2 = key2;
    node -> smallitem = small;
    node -> largeitem = large;
    node -> left = left;
    node -> middle = middle;
    node -> right = right;
    return node;
}



void Dictionary23Tree::nodeEdit(btreeNode *&rootptr, int key, string word)
{
    if(key < rootptr -> key1)
    {
        rootptr -> key2 = rootptr -> key1;
        rootptr -> largeitem = rootptr -> smallitem;
        rootptr -> key1 = key;
        rootptr -> smallitem = word;
    }
    else
    {
        rootptr -> key2 = key;
        rootptr -> largeitem = word;
    
    }
    
    rootptr -> full = true;
        


}


// Checks if a node has a child or not
bool Dictionary23Tree::child(btreeNode *rootptr)
{
    if((rootptr -> left == NULL) && (rootptr -> middle == NULL) && (rootptr -> right == NULL))
        return false;
    return true;
}




// Finds the middle value that is to be moved upwards in the tree
int Dictionary23Tree::middleElement(btreeNode *rootptr, btreeNode *item)
{
   int middle;
   if(rootptr != NULL)
   {
       middle = rootptr -> key1;
    if(((item -> key1) > middle) && ((item -> key1) < rootptr -> key2))
        middle = item -> key1;
    else if((item -> key1) > (rootptr -> key2))
        middle = rootptr -> key2;
   }
    return middle;
    
    
}


// Changes the item in a node
btreeNode* Dictionary23Tree::change(btreeNode *&rootptr, btreeNode *item, int midkey)
{
    btreeNode *ret;
    if(midkey == rootptr -> key1)
    {
        ret = nodeMaker(rootptr -> key1, rootptr -> smallitem, NULL, NULL, NULL);
        rootptr -> key1 = item -> key1;
        rootptr -> smallitem = item -> smallitem;
    }
    else if(midkey == rootptr -> key2)
    {
        ret = nodeMaker(rootptr -> key2, rootptr -> largeitem, NULL, NULL, NULL);
        rootptr -> key2 = item -> key1;
        rootptr -> largeitem = item -> smallitem;
    }
    else
        ret = nodeMaker(item -> key1, item -> smallitem, NULL, NULL, NULL);
    
    return ret;
}




// Splits the node if it has more than 2 items
void Dictionary23Tree::split(btreeNode *&rootptr,btreeNode *&parent, btreeNode *orgRoot, btreeNode *item)
{
    while(orgRoot != NULL)
    {
        treeHeight++;
        orgRoot = orgRoot -> middle;
    
    }
    counter++;
    if(counter == treeHeight)
        return;
    else
    {
        rootptr -> midkey = middleElement(rootptr,item);
    if((rootptr == parent) && (child(rootptr) == false))
    {
    
        if(rootptr -> midkey == item -> key1)
        {
            btreeNode *temp = nodeMaker(rootptr -> midkey, item -> smallitem, NULL, NULL, NULL);
            btreeNode *left = nodeMaker(rootptr -> key1, rootptr -> smallitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(rootptr ->key2, rootptr -> largeitem, NULL, NULL, NULL);
            temp -> left = left;
            temp -> middle = right;
            rootptr = temp;
            parent = rootptr;
            temp = NULL;
            //return;
        }
    else if(rootptr -> midkey == rootptr -> key1)
        {
            btreeNode *temp = nodeMaker(rootptr -> midkey, rootptr -> smallitem, NULL, NULL, NULL);
            btreeNode *left = nodeMaker(item -> key1, item -> smallitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(rootptr ->key2, rootptr -> largeitem, NULL, NULL, NULL);
            temp -> left = left;
            temp -> middle = right;
            rootptr = temp;
            parent = rootptr;
            temp = NULL;
            //return;
        }
    else
        {
            btreeNode *temp = nodeMaker(rootptr -> midkey, rootptr -> largeitem, NULL, NULL, NULL);
            btreeNode *left = nodeMaker(rootptr -> key1, rootptr -> smallitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(item ->key1, item -> smallitem, NULL, NULL, NULL);
            temp -> left = left;
            temp -> middle = right;
            rootptr = temp;
            parent = rootptr;
            temp = NULL;
            //return;
        }
    }
    else if((rootptr == parent) && (child(rootptr) == true) && (rootptr -> left != NULL) && (rootptr -> right != NULL))
    {
        
        if(rootptr -> midkey == item -> key1)
        {
            btreeNode *temp = nodeMaker(rootptr-> midkey, item -> smallitem, NULL,NULL,NULL);
            btreeNode *left = nodeMaker(rootptr -> key1, rootptr -> smallitem, rootptr -> left, rootptr -> middle, NULL);
            btreeNode *rchild1 = nodeMaker(rootptr -> key2, rootptr -> largeitem, NULL, NULL, NULL);
            btreeNode *rchild2 = nodeMaker(rootptr -> right -> key2, rootptr -> right -> largeitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(rootptr -> right -> key1, rootptr -> right -> smallitem, rchild1, rchild2, NULL);
            temp -> left = left;
            temp -> middle = right;
            parent = temp;
            rootptr = temp;
            temp = NULL;
            //return;
            
        }
        
        else if(rootptr -> midkey == rootptr -> key1)
        {
            btreeNode *temp = nodeMaker(rootptr -> midkey, rootptr -> smallitem, NULL, NULL, NULL);
            btreeNode *left = nodeMaker(item -> key1, item -> smallitem, rootptr -> left, rootptr -> middle, NULL);
            btreeNode *rchild1 = nodeMaker(rootptr -> key2, rootptr -> largeitem, NULL, NULL, NULL);
            btreeNode *rchild2 = nodeMaker(rootptr -> right -> key2, rootptr -> right -> largeitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(rootptr -> right -> key1, rootptr -> right -> smallitem, rchild1, rchild2, NULL);
            temp -> left = left;
            temp -> middle = right;
            parent = temp;
            rootptr = temp;
            temp = NULL;
            //return;
        
        }
        
        else
        {
            btreeNode *temp = nodeMaker(rootptr -> midkey, rootptr -> largeitem, NULL, NULL, NULL);
            btreeNode *left = nodeMaker(rootptr -> key1, rootptr -> smallitem, rootptr -> left, rootptr -> middle, NULL);
            btreeNode *rchild1 = nodeMaker(rootptr -> right -> key1, rootptr -> right -> smallitem, NULL, NULL, NULL);
            btreeNode *rchild2 = nodeMaker(rootptr -> right -> key2, rootptr -> right -> largeitem, NULL, NULL, NULL);
            btreeNode *right = nodeMaker(item -> key1, item -> smallitem, rchild1, rchild2, NULL);
            temp -> left = left;
            temp -> middle = right;
            parent = temp;
            rootptr = temp;
            temp = NULL;
            //return;
        }
    }

    else
    {
        if((parent -> full == false) && (parent -> left != NULL) && (parent -> right) != NULL)
        {
            
            btreeNode *tempItem = change(rootptr,item,rootptr -> midkey);
            nodeEdit(parent, tempItem -> key1, tempItem -> smallitem);
            btreeNode *tempLeft;
            btreeNode *tempMid;
            btreeNode *tempRight;
            if(parent -> left == rootptr)
            {
                tempLeft = nodeMaker(parent -> left -> key1,parent -> left -> smallitem , NULL, NULL, NULL);
                tempMid = nodeMaker(rootptr -> key2, rootptr -> largeitem, NULL, NULL, NULL);
                tempRight = parent -> right;
            }
            else
            {
                tempLeft = parent -> left;
                tempMid = nodeMaker(rootptr -> key1, rootptr -> largeitem, NULL, NULL, NULL);
                tempRight = nodeMaker(rootptr -> key2, rootptr -> largeitem, NULL, NULL, NULL);
            }
            parent -> left = tempLeft;
            parent -> middle = tempMid;
            parent -> right = tempRight;
            tempLeft = NULL;
            tempMid = NULL;
            tempRight = NULL;
            rootptr = parent;
            //return;
            
            
        
        }
        
        else
        {
             btreeNode *tempItem = change(rootptr,item,rootptr -> midkey);
             split(parent, parent, orgRoot, tempItem);
            
        }
    
    }
  }
}










