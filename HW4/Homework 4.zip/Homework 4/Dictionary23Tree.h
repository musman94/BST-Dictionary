//
//  Dictionary23Tree.h
//  HW4
//
//  Created by Muhammad Usman on 4/19/16.
//  Copyright © 2016 Muhammad Usman. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

#ifndef Dictionary23Tree_h
#define Dictionary23Tree_h
struct btreeNode
{
    int key1;
    int key2;
    int midkey = -100000;
    bool full = false;
    string smallitem,largeitem;
    btreeNode *left;
    btreeNode *middle;
    btreeNode *right;
};



//2-3 tree implementation for the dictionary
class Dictionary23Tree
{
public:
    //Constructor that constructs the dictionary from the input file
    Dictionary23Tree( string dictionaryFile );
    //Destructor
    ~Dictionary23Tree();
    //Inserts the given word into the dictionary
    void insert( string word );
    //Searches the given word in the dictionary, and returns the number //of comparisons made and whether the word is found or not
    void search( string word, int& numComparisons, bool& found );
    //Searches all words in the query file in the dictionary, and //summarizes the results in the output file
    void search( string queryFile, string outputFile );
    void add(btreeNode *&rootptr, btreeNode *& parent, btreeNode *item);
    btreeNode* nodeMaker(int key, string word, btreeNode *left, btreeNode *middle, btreeNode *right);
    btreeNode* twonodeMaker(int key1, int key2, string small, string large, btreeNode* left, btreeNode *middle, btreeNode *right);
    btreeNode* change(btreeNode *&rootptr, btreeNode *item, int midkey);
    //void nodeEdit(btreeNode *& node, btreeNode* item);
    void nodeEdit(btreeNode *&rootptr, int key, string word);
    bool child(btreeNode *rootptr);
    void split(btreeNode *&rootptr,btreeNode *&parent, btreeNode *orgRoot,btreeNode *item);
    void find(btreeNode* rootptr, string query_word, int key, int &numComaprisions, int &check);
    int middleElement(btreeNode *rootptr, btreeNode *item);
    

private:
    btreeNode *orgRoot;
    btreeNode *rootptr;
    btreeNode *parent;
    int query_size;
    int max_comp;
    int total_comp;
    int numcomparisions;
    int check;
    int treeHeight;
    int counter;
    double avg_comp;
    bool found;
    string outfile;
    
};

#endif /* Dictionary23Tree_h */
